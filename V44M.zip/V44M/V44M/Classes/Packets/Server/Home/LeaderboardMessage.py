from Classes.ClientsManager import ClientsManager
from Classes.Packets.PiranhaMessage import PiranhaMessage
from Database.DatabaseHandler import ClubDatabaseHandler, DatabaseHandler
import json

class LeaderboardMessage(PiranhaMessage):
    
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    def encode(self, fields, player):
        db = DatabaseHandler()
        players = db.load_all()
        playerscount = len(db.getAll())
        clubdb_instance = ClubDatabaseHandler()
        
        self.writeVInt(fields["Type"]) # Leaderboard Variation
        self.writeVInt(0)
        if fields["CsvID"] == 16:
        	self.writeDataReference(16, fields["Brawler"])
        else:
        	self.writeDataReference(0, 0)
        if fields["IsLocal"]:
        	self.writeString("BY")
        else:
        	self.writeString()

        if fields["Type"] == 1:
        	if len(players) >= 200:
        		self.writeVInt(200) # Players Count
        	else:
        		self.writeVInt(playerscount) # Players Count
        	def by_trophy(players):
        		return players["Trophies"]
        	players.sort(key = by_trophy, reverse = True)
        	for data in players:
        		self.writeVInt(data["ID"][0])
        		self.writeVInt(data["ID"][1])
        		
        		self.writeVInt(1)
        		self.writeVInt(data["Trophies"]) #trophies
        		
        		self.writeVInt(1)
        		try:
        			clubData = json.loads(clubdb_instance.getClubWithLowID(data["AllianceID"][1])[0][1])
        		except IndexError:
        			data["AllianceID"] = [0, 0]
        		if data["AllianceID"] != [0, 0]:
        		    clubData = json.loads(clubdb_instance.getClubWithLowID(data["AllianceID"][1])[0][1])
        		    self.writeString(clubData["Name"]) # Club Name
        		else:
        		    self.writeString() # Club Name
        		
        		self.writeString(data["Name"]) # Player Name
        		self.writeVInt(0)
        		self.writeVInt(28000000 + data["Thumbnail"]) # Player Thumbnail
        		self.writeVInt(43000000 + data["Namecolor"]) # Player Name Color
        		try:
        			data["BPActivated"]
        		except KeyError:
        			data["BPActivated"] = False
        		if data["BPActivated"]:
        			self.writeVInt(46000000 + data["Namecolor"]) # Color Gradients
        		else:
        			self.writeVInt(-1) # Color Gradients
        		self.writeVInt(0) #UNK
        		if players.index(data) + 1 == 200:
        			break
        	
        	self.writeVInt(player.Trophies)
        	for data in players:
        		if data["ID"] == player.ID:
        			if players.index(data) + 1 > 200:
        				self.writeVInt(0) # Player place in Top
        			else:
        				self.writeVInt(players.index(data) + 1) # Player place in Top

        elif fields["Type"] == 2:
        	clubs = clubdb_instance.getAllClub()
        	if len(clubs) >= 200:
        		self.writeVInt(200) # Clubs Count
        	else:
        		self.writeVInt(len(clubs)) # Clubs Count
        	def by_trophy(clubs):
        		clubtrophies = clubdb_instance.getTotalTrophies(clubs)
        		return clubtrophies
        	clubs.sort(key = by_trophy, reverse = True)
        	for data in clubs:
        		self.writeVLong(data["HighID"], data["LowID"]) # ClubID
        		self.writeVInt(1)
        		self.writeVInt(clubdb_instance.getTotalTrophies(data)) # Club Trophies
        		self.writeVInt(2)
        		self.writeString(data["Name"]) # Club Name
        		self.writeVInt(len(data["Members"]))
        		self.writeDataReference(8, data["BadgeID"])
        		if clubs.index(data) + 1 == 200:
        			break
        	
        	self.writeVInt(0)
        	for data in clubs:
        			if [data["HighID"], data["LowID"]] == player.AllianceID:
        				if clubs.index(data) + 1 == 200:
        					self.writeVInt(0)
        				else:
        					self.writeVInt(clubs.index(data) + 1) # Club place in Top

        if fields["Type"] == 0:
        	if len(players) >= 200:
        		self.writeVInt(200) # Players Count
        	else:
        		self.writeVInt(playerscount) # Players Count
        	def by_trophy(players):
        		return players["Trophies"]
        	players.sort(key = by_trophy, reverse = True)
        	for data in players:
        		self.writeVInt(data["ID"][0])
        		self.writeVInt(data["ID"][1])
        		
        		self.writeVInt(1)
        		self.writeVInt(data["Trophies"]) #trophies
        		
        		self.writeVInt(1)
        		try:
        			clubData = json.loads(clubdb_instance.getClubWithLowID(data["AllianceID"][1])[0][1])
        		except KeyError:
        			data["AllianceID"] = [0, 0]
        		if data["AllianceID"] != [0, 0]:
        		    clubData = json.loads(clubdb_instance.getClubWithLowID(data["AllianceID"][1])[0][1])
        		    self.writeString(clubData["Name"]) # Club Name
        		else:
        		    self.writeString() # Club Name
        		
        		self.writeString(data["Name"]) # Player Name
        		self.writeVInt(0)
        		self.writeVInt(28000000 + data["Thumbnail"]) # Player Thumbnail
        		self.writeVInt(43000000 + data["Namecolor"]) # Player Name Color
        		if data["BPActivated"]:
        			self.writeVInt(46000000 + data["Namecolor"]) # Color Gradients
        		else:
        			self.writeVInt(-1) # Color Gradients
        		self.writeVInt(0) #UNK
        		if players.index(data) + 1 == 200:
        			break
        	
        	self.writeVInt(player.Trophies)
        	for data in players:
        		if data["ID"] == player.ID:
        			if players.index(data) + 1 > 200:
        				self.writeVInt(0) # Player place in Top
        			else:
        				self.writeVInt(players.index(data) + 1) # Player place in Top

        self.writeVInt(0)
        self.writeVInt(0)
        self.writeString("BY")

        
    def decode(self):
        return {}

    def execute(message, calling_instance, fields):
        pass

    def getMessageType(self):
        return 24403

    def getMessageVersion(self):
        return self.messageVersion