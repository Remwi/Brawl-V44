from Classes.ClientsManager import ClientsManager
from Classes.Packets.PiranhaMessage import PiranhaMessage
from Classes.Messaging import Messaging

from Classes.ByteStream import ByteStream
import json


ShopUpdated = False

class AnalyticEventMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0
        

    def decode(self):
        fields = {}
        fields["Type"] = self.readString()
        fields["Event"] = self.readString()
        print(fields)
        return fields

    def encode(self):
    	pass
    
    def execute(message, calling_instance, fields):
        global ShopUpdated
        event = json.loads(fields["Event"])
        if fields["Type"] == "Economy" and event["subType"] == "openShop" and ShopUpdated != True:
        	fields["Socket"] = calling_instance.client
        	fields["PlayerID"] = calling_instance.player.ID
        	fields["Command"] = {"ID": 211}
        	ShopUpdated = True
        	#Messaging.sendMessage(24111, fields)

    def getMessageType(self):
        return 10110

    def getMessageVersion(self):
        return self.messageVersion