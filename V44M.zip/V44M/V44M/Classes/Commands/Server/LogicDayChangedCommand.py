from Classes.Commands.LogicServerCommand import LogicServerCommand
from Classes.ByteStreamHelper import ByteStreamHelper
from Static.StaticData import StaticData
import Configuration
from Database.DatabaseHandler import DatabaseHandler
import json


class LogicDayChangedCommand(LogicServerCommand):
    def __init__(self, commandData):
        super().__init__(commandData)

    def encode(self, fields):
        self.writeBoolean(True)
        
        self.writeVInt(0)

        if Configuration.settings["ChallengeEnabled"]:
        	ChallengeStages = Configuration.settings["ChallengeStages"]
        else:
        	ChallengeStages = 0
        
        self.writeVInt(21 + ChallengeStages) # Count

        self.writeVInt(1)
        self.writeVInt(2)
        self.writeVInt(3)
        self.writeVInt(4)
        self.writeVInt(5)
        self.writeVInt(6)
        self.writeVInt(7)
        self.writeVInt(8)
        self.writeVInt(9)
        self.writeVInt(10)
        self.writeVInt(11)
        self.writeVInt(12)
        self.writeVInt(13)
        self.writeVInt(14)
        self.writeVInt(15)
        self.writeVInt(16)
        self.writeVInt(17)
        self.writeVInt(18)
        if Configuration.settings["ChallengeEnabled"]:
        	for i in range(Configuration.settings["ChallengeStages"]):
        		self.writeVInt(20 + i)
        self.writeVInt(30)
        self.writeVInt(31)
        self.writeVInt(32)

        EventsData = StaticData.EventsData
        
        self.writeVInt(len(EventsData) + 4 + int(Configuration.settings["MysteryModeEnabled"]) + ChallengeStages + 1) # Events Count
        for i in EventsData:
              # Default Slots Start Array #
              self.writeVInt(-1)
              self.writeVInt(EventsData.index(i) + 1)  # EventType
              self.writeVInt(i['CountdownTimer'])  # EventsBeginCountdown
              self.writeVInt(i['Timer'])  # Timer
              self.writeVInt(i['TokensReward'])  # tokens reward for new event
              self.writeDataReference(15, i['ID'])  # MapID
              self.writeVInt(-64)  # GameModeVariation
              self.writeVInt(i['Status'])  # Status
              self.writeString()
              self.writeVInt(0)
              self.writeVInt(0)
              self.writeVInt(0)
              if i['Modifier'] > 0:
                 self.writeBoolean(True)
                 self.writeVInt(i['Modifier']) #Modifer ID
              else:
                 self.writeBoolean(False)
              self.writeVInt(0)
              self.writeVInt(0)
              self.writeBoolean(False)  # Map Maker Map Structure Array
              self.writeVInt(0)
              self.writeBoolean(False)  # Power League Data Array
              self.writeVInt(0)
              self.writeVInt(0)
              self.writeBoolean(False) # ChronosTextEntry
              self.writeBoolean(False)
              self.writeBoolean(False) # ChronosTextEntry
              self.writeBoolean(False)
              self.writeVInt(-1)
              self.writeBoolean(False) # ChronosFileEntry
              self.writeBoolean(False)
              self.writeVInt(-1)
              # Default Slots End Array #

        # Challenge Slot Start Array #
        db_instance = DatabaseHandler()
        player_data = json.loads(db_instance.getPlayerEntry(fields["PlayerID"])[2])
        try:
        	player_data["Challenges"]
        except KeyError:
        	player_data["Challenges"] = {}
        try:
            challenge = Configuration.settings["ChallengeLogicName"]
            player_data["Challenges"][challenge]
        except KeyError:
        	player_data["Challenges"][challenge] = {'Seen': False, 'Defeates': 0, 'Wins': 0}
        challenge = Configuration.settings["ChallengeLogicName"]
        challengeData = player_data["Challenges"][challenge]
        if Configuration.settings["ChallengeEnabled"]:
        	for i in range(Configuration.settings["ChallengeStages"]):
        		self.writeVInt(-1)
        		self.writeVInt(20 + i)  # EventType
        		self.writeVInt(0)  # EventsBeginCountdown
        		self.writeVInt(51208)  # Timer
        		self.writeVInt(0)  # tokens reward for new event
        		self.writeDataReference(15, Configuration.settings["ChallengeMaps"][i])  # MapID
        		self.writeVInt(-64)  # GameModeVariation
        		if challengeData["Seen"] == False:
        			self.writeVInt(0)  # State
        		elif challengeData["Seen"] == True:
        			self.writeVInt(1)  # State
        		elif challengeData["Wins"] >= 3:
        			self.writeVInt(2)  # State
        		self.writeString() #?
        		self.writeVInt(Configuration.settings["ChallengeFinalReward"]["Type"]) # Challenge FinalReward
        		self.writeVInt(challengeData["Defeates"]) #Defeates
        		self.writeVInt(Configuration.settings["ChallengeMapsWins"][i]) #Wins need
        		self.writeVInt(0)  # Modifiers
        		self.writeVInt(challengeData["Wins"]) #Wins
        		self.writeVInt(Configuration.settings["ChallengeVariation"]) #Challenge Variation
        		self.writeBoolean(False)  # Map Maker Map Structure Array
        		self.writeVInt(0) #Defeates(if buyed lives)
        		self.writeBoolean(False)  # Power League Data Array
        		self.writeVInt(0) #?
        		self.writeVInt(0) #?
        		self.writeBoolean(True) # ChronosTextEntry
        		self.writeInt(0)
        		self.writeString(Configuration.settings["ChallengeName"])
        		self.writeBoolean(False)# Stage Name
        		self.writeBoolean(False) # ChronosTextEntry
        		self.writeBoolean(True) # Challenge Final Reward
        		for x in range(1):
        			self.writeVInt(Configuration.settings["ChallengeFinalReward"]["Type"])
        			self.writeVInt(Configuration.settings["ChallengeFinalReward"]["Amount"])
        			self.writeDataReference(Configuration.settings["ChallengeFinalReward"]["Brawler"][0], Configuration.settings["ChallengeFinalReward"]["Brawler"][1])
        			self.writeVInt(Configuration.settings["ChallengeFinalReward"]["Extra"])
        		self.writeVInt(1) # Challenge Lives Array
        		for x in range(1):
        			self.writeVInt(0) # Gems
        		self.writeBoolean(False) # ChronosFileEntry
        		self.writeBoolean(False) # Array
        		self.writeVInt(-1) # Array
        # Challenge Slot Array End #
        
        # Club League Slots Start Array #
        # Club League Default Map Array #
        self.writeVInt(-1)
        self.writeVInt(16)  # EventType
        self.writeVInt(432000)  # EventsBeginCountdown
        self.writeVInt(51208)  # Timer
        self.writeVInt(0)  # tokens reward for new event
        self.writeDataReference(15, 7)  # MapID
        self.writeVInt(-64)  # GameModeVariation
        self.writeVInt(2)  # State
        self.writeString()
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False)  # Map Maker Map Structure Array
        self.writeVInt(0)
        self.writeBoolean(False)  # Power League Data Array
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False)  # ChronosTextEntry
        self.writeBoolean(False)
        self.writeBoolean(False) # ChronosTextEntry
        self.writeBoolean(False)
        self.writeVInt(-1)
        self.writeBoolean(False) # ChronosFileEntry
        self.writeBoolean(False)
        self.writeVInt(-1)
        
        # Club League Power Match Array #
        self.writeVInt(-1)
        self.writeVInt(17)  # EventType
        self.writeVInt(432000)  # EventsBeginCountdown
        self.writeVInt(51208)  # Timer
        self.writeVInt(0)  # tokens reward for new event
        self.writeDataReference(15, 25)  # MapID
        self.writeVInt(-64)  # GameModeVariation
        self.writeVInt(2)  # State
        self.writeString() 
        self.writeVInt(0) 
        self.writeVInt(0) 
        self.writeVInt(0)
        self.writeVInt(0)  # Modifiers
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False)  # Map Maker Map Structure Array
        self.writeVInt(0)
        self.writeBoolean(False)  # Power League Data Array
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False)  # ChronosTextEntry
        self.writeBoolean(False)
        self.writeBoolean(False) # ChronosTextEntry
        self.writeBoolean(False)
        self.writeVInt(-1)
        self.writeBoolean(False) # ChronosFileEntry
        self.writeBoolean(False)
        self.writeVInt(-1)
        # Club League Slots End Array #
        
        # Power League Solo Mode #
        self.writeVInt(-1)
        self.writeVInt(14)  # EventType
        self.writeVInt(0)  # EventsBeginCountdown
        self.writeVInt(99999)  # Timer
        self.writeVInt(0)  # tokens reward for new event
        self.writeDataReference(0, 0)  # MapID
        self.writeVInt(-64)  # GameModeVariation
        self.writeVInt(2)  # State
        self.writeString()
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False)  # Map Maker Map Structure Array
        self.writeVInt(0)
        self.writeBoolean(True)  # Power League Data Array
        # Power League Data Array Start #
        self.writeVInt(9) # Season
        self.writeString("TID_BRAWL_PASS_SEASON_12") # Name Season
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(3) # Quests Count
        
        self.writeByte(3) # LogicRewardConfig
        self.writeByte(4) # Quest Type
        self.writeVInt(30) # Rank
        self.writeVInt(1) # Item Array
        self.writeVInt(25) # ItemType
        self.writeVInt(1) 
        self.writeVInt(0)
        self.writeVInt(106) # Thumbnail ID
        
        self.writeByte(3) # LogicRewardConfig
        self.writeByte(2) # Quest Type
        self.writeVInt(7) # Rank
        self.writeVInt(1) # Item Array
        self.writeVInt(25) # ItemType
        self.writeVInt(1) 
        self.writeVInt(0)
        self.writeVInt(107) # Thumbnail ID
        
        self.writeByte(3) # LogicRewardConfig
        self.writeByte(4) # Quest Type
        self.writeVInt(60) # Wins need
        self.writeVInt(1) # Item Array
        self.writeVInt(26) # ItemType
        self.writeVInt(1) 
        self.writeVInt(0)
        self.writeVInt(534) # SkinID
        
        self.writeVInt(19) # Road Count
        
        self.writeVInt(1) # Rank
        self.writeVInt(500) # Starpoints
        self.writeVInt(2) # Rank
        self.writeVInt(1000) # Starpoints
        self.writeVInt(3)  # Rank
        self.writeVInt(2000) # Starpoints
        self.writeVInt(4)  # Rank
        self.writeVInt(2500) # Starpoints
        self.writeVInt(5)  # Rank
        self.writeVInt(3000) # Starpoints
        self.writeVInt(6)  # Rank
        self.writeVInt(3750) # Starpoints
        self.writeVInt(7)  # Rank
        self.writeVInt(4500) # Starpoints
        self.writeVInt(8)  # Rank
        self.writeVInt(5500) # Starpoints
        self.writeVInt(9)  # Rank
        self.writeVInt(7000) # Starpoints
        self.writeVInt(10)  # Rank
        self.writeVInt(8750) # Starpoints
        self.writeVInt(11)  # Rank
        self.writeVInt(10000) # Starpoints
        self.writeVInt(12)  # Rank
        self.writeVInt(12500) # Starpoints
        self.writeVInt(13)  # Rank
        self.writeVInt(15000) # Starpoints
        self.writeVInt(14)  # Rank
        self.writeVInt(17500) # Starpoints
        self.writeVInt(15)  # Rank
        self.writeVInt(20000) # Starpoints
        self.writeVInt(16)  # Rank
        self.writeVInt(25000) # Starpoints
        self.writeVInt(17)  # Rank
        self.writeVInt(30000) # Starpoints
        self.writeVInt(18)  # Rank
        self.writeVInt(40000) # Starpoints
        self.writeVInt(19)  # Rank
        self.writeVInt(50000) # Starpoints
        # Power League Data Array End #
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False)  # ChronosTextEntry
        self.writeBoolean(False)
        self.writeBoolean(False) # ChronosTextEntry
        self.writeBoolean(False)
        self.writeVInt(-1)
        self.writeBoolean(False) # ChronosFileEntry
        self.writeBoolean(False)
        self.writeVInt(-1)
        
        # Power League Team Mode #
        self.writeVInt(-1)
        self.writeVInt(15)  # EventType
        self.writeVInt(0)  # EventsBeginCountdown
        self.writeVInt(99999)  # Timer
        self.writeVInt(0)  # tokens reward for new event
        self.writeDataReference(0, 0)  # MapID
        self.writeVInt(-64)  # GameModeVariation
        self.writeVInt(2)  # State
        self.writeString()
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(3)
        self.writeVInt(0)  # Modifiers
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False)  # Map Maker Map Structure Array
        self.writeVInt(0)
        self.writeBoolean(True)  # Power League Data Array
        # Power League Data Array Start #
        self.writeVInt(9) # Season
        self.writeString("TID_BRAWL_PASS_SEASON_12") # Name Season
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(3) # Quests Count
        
        self.writeByte(3) # LogicRewardConfig
        self.writeByte(4) # Quest Type
        self.writeVInt(30) # Rank
        self.writeVInt(1) # Item Array
        self.writeVInt(25) # ItemType
        self.writeVInt(1) 
        self.writeVInt(0)
        self.writeVInt(106) # Thumbnail ID
        
        self.writeByte(3) # LogicRewardConfig
        self.writeByte(2) # Quest Type
        self.writeVInt(7) # Rank
        self.writeVInt(1) # Item Array
        self.writeVInt(25) # ItemType
        self.writeVInt(1) 
        self.writeVInt(0)
        self.writeVInt(107) # Thumbnail ID
        
        self.writeByte(3) # LogicRewardConfig
        self.writeByte(4) # Quest Type
        self.writeVInt(60) # Wins need
        self.writeVInt(1) # Item Array
        self.writeVInt(26) # ItemType
        self.writeVInt(1) 
        self.writeVInt(0)
        self.writeVInt(534) # SkinID
        
        self.writeVInt(19) # Road Count
        
        self.writeVInt(1) # Rank
        self.writeVInt(500) # Starpoints
        self.writeVInt(2) # Rank
        self.writeVInt(1000) # Starpoints
        self.writeVInt(3)  # Rank
        self.writeVInt(2000) # Starpoints
        self.writeVInt(4)  # Rank
        self.writeVInt(2500) # Starpoints
        self.writeVInt(5)  # Rank
        self.writeVInt(3000) # Starpoints
        self.writeVInt(6)  # Rank
        self.writeVInt(3750) # Starpoints
        self.writeVInt(7)  # Rank
        self.writeVInt(4500) # Starpoints
        self.writeVInt(8)  # Rank
        self.writeVInt(5500) # Starpoints
        self.writeVInt(9)  # Rank
        self.writeVInt(7000) # Starpoints
        self.writeVInt(10)  # Rank
        self.writeVInt(8750) # Starpoints
        self.writeVInt(11)  # Rank
        self.writeVInt(10000) # Starpoints
        self.writeVInt(12)  # Rank
        self.writeVInt(12500) # Starpoints
        self.writeVInt(13)  # Rank
        self.writeVInt(15000) # Starpoints
        self.writeVInt(14)  # Rank
        self.writeVInt(17500) # Starpoints
        self.writeVInt(15)  # Rank
        self.writeVInt(20000) # Starpoints
        self.writeVInt(16)  # Rank
        self.writeVInt(25000) # Starpoints
        self.writeVInt(17)  # Rank
        self.writeVInt(30000) # Starpoints
        self.writeVInt(18)  # Rank
        self.writeVInt(40000) # Starpoints
        self.writeVInt(19)  # Rank
        self.writeVInt(50000) # Starpoints
        # Power League Data Array End #
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False)  # ChronosTextEntry
        self.writeBoolean(False)
        self.writeBoolean(False) # ChronosTextEntry
        self.writeBoolean(False)
        self.writeVInt(-1)
        self.writeBoolean(False) # ChronosFileEntry
        self.writeBoolean(False)
        self.writeVInt(-1)
        
        # Mystery Mode #
        if Configuration.settings["MysteryModeEnabled"]:
        	self.writeVInt(-1)
        	self.writeVInt(18)  # EventType
        	self.writeVInt(0)  # EventsBeginCountdown
        	self.writeVInt(51208)  # Timer
        	self.writeVInt(0)  # tokens reward for new event
        	self.writeDataReference(15, random.choice(Configuration.settings["MysteryModeMaps"]))  # MapID
        	self.writeVInt(-64)  # GameModeVariation
        	self.writeVInt(2)  # State
        	self.writeString()
        	self.writeVInt(0)
        	self.writeVInt(0)
        	self.writeVInt(0)
        	Modifiers = [1, 2, 3, 4, 5, 11, 13, 14, 16]
        	modifierscount = random.randint(1, 4)
        	modifier1 = random.choice(Modifiers)
        	modifier2 = random.choice(Modifiers)
        	while modifier2 == modifier1:
        		modifier2 = random.choice(Modifiers)
        	modifier3 = random.choice(Modifiers)
        	while modifier3 == modifier2 or modifier3 == modifier1:
        		modifier3 = random.choice(Modifiers)
        	modifier4 = random.choice(Modifiers)
        	while modifier4 == modifier3 or modifier4 == modifier2 or modifier4 == modifier1:
        		modifier4 = random.choice(Modifiers)
        	if Configuration.settings["MysteryModeModifiersEnabled"]:
        		self.writeVInt(modifierscount)  # Modifiers
        		if modifierscount >= 1:
        			self.writeVInt(modifier1)
        		if modifierscount >= 2:
        			self.writeVInt(modifier2)
        		if modifierscount >= 3:
        			self.writeVInt(modifier3)
        		if modifierscount == 4:
        			self.writeVInt(modifier4)
        	else:
        		self.writeVInt(0)  # Modifiers
        	self.writeVInt(0)
        	self.writeVInt(0)
        	self.writeBoolean(False)  # Map Maker Map Structure Array
        	self.writeVInt(0)
        	self.writeBoolean(False)  # Power League Data Array
        	self.writeVInt(0)
        	self.writeVInt(0)
        	self.writeBoolean(True)  # ChronosTextEntry
        	self.writeInt(0)
        	self.writeString("Mystery Mode")
        	self.writeBoolean(False)
        	self.writeBoolean(True) # ChronosTextEntry
        	self.writeInt(0)
        	self.writeString(Configuration.settings["MysteryModeName"])
        	self.writeBoolean(False)
        	self.writeVInt(-1)
        	self.writeBoolean(False) # ChronosFileEntry
        	self.writeBoolean(False)
        	self.writeVInt(-1)
        
        self.writeVInt(-1)
        self.writeVInt(30)  # EventType
        self.writeVInt(0)  # EventsBeginCountdown
        self.writeVInt(9999)  # Timer
        self.writeVInt(0)  # tokens reward for new event
        self.writeDataReference(15, 68)  # MapID
        self.writeVInt(-64)  # GameModeVariation
        self.writeVInt(1)  # State
        self.writeString()
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False)  # Map Maker Map Structure Array
        self.writeVInt(0)
        self.writeBoolean(False)  # Power League Data Array
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False)  # ChronosTextEntry
        self.writeBoolean(False)
        self.writeBoolean(False) # ChronosTextEntry
        self.writeBoolean(False)
        self.writeVInt(-1)
        self.writeBoolean(False) # ChronosFileEntry
        self.writeBoolean(False)
        self.writeVInt(-1)

        self.writeVInt(0) # Comming Events

        ByteStreamHelper.encodeIntList(self, [20, 35, 75, 140, 290, 480, 800, 1250, 1875, 2800]) # Brawler Upgrade Cost
        ByteStreamHelper.encodeIntList(self, [20, 50, 140, 280]) # Shop Coins Price
        ByteStreamHelper.encodeIntList(self, [150, 400, 1200, 2600]) # Shop Coins Amount

        self.writeBoolean(True)  # Show Offers Packs

        self.writeVInt(0) # ReleaseEntry

        self.writeVInt(24)  # IntValueEntry

        self.writeLong(10008, 501)
        self.writeLong(65, 2)
        self.writeLong(1, 41000000 + Configuration.settings["Theme"])  # ThemeID
        self.writeLong(60, 36270)
        self.writeLong(66, 0) # Garveyard Shift
        self.writeLong(61, 36270)  # SupportDisabled State | if 36218 < state its true
        self.writeLong(47, 41381)
        self.writeLong(29, Configuration.settings["SkinPack"])  # Skin Group Active For Campaign
        self.writeLong(48, 26217)
        self.writeLong(50, 1)  # Coming up quests placeholder
        self.writeLong(1100, 500)
        self.writeLong(1101, 500)
        self.writeLong(1003, 1)
        self.writeLong(36, 0)
        self.writeLong(14, Configuration.settings["DoubleTokenEvent"])  # Double Token Event
        self.writeLong(31, Configuration.settings["GoldRushEvent"])  # Gold rush event
        self.writeLong(79, 149999)
        self.writeLong(80, 160000)
        self.writeLong(28, Configuration.settings["ChallengeLives"]) # Challenge Lives
        self.writeLong(74, 1)
        self.writeLong(78, 1)
        self.writeLong(17, 4)
        self.writeLong(10046, 1)
        self.writeLong(87, 1)

        self.writeVInt(3)  # Timed Int Value Entry

        self.writeVInt(14)
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeVInt(739760) # Time left

        self.writeVInt(29)
        self.writeVInt(15)
        self.writeVInt(0)
        self.writeVInt(691200) # Time left

        self.writeVInt(29)
        self.writeVInt(10)
        self.writeVInt(0)
        self.writeVInt(1330340) # Time left

        self.writeVInt(0)  # Custom Event

        self.writeVInt(0)
        
        LogicServerCommand.encode(self, fields)
        return self.messagePayload

    def decode(self, calling_instance):
        pass

    def getCommandType(self):
        return 204