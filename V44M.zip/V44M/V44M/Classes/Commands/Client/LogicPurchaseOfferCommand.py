import json

from Classes.Commands.LogicCommand import LogicCommand
from Classes.Messaging import Messaging
from Database.DatabaseHandler import DatabaseHandler
from Classes.ByteStream import ByteStream
import random
from Static.StaticData import StaticData
from Classes.Files.Classes.Cards import Cards
from Classes.Files.Classes.Skins import Skins
from Classes.Files.Classes.Characters import Characters
from Classes.Files.Classes.Pins import Pins
import Configuration
from Static.StaticData import StaticData


BrawlerPins = {
    0: {'Common': [152, 154, 210], 'Rare': [153, 499], 'Epic': [155, 266]},
    1: {'Common': [45, 47, 190], 'Rare': [46, 471], 'Epic': [48, 241, 272]},
    2: {'Common': [35, 37, 188], 'Rare': [36, 466], 'Epic': [38, 239]},
    3: {'Common': [30, 32, 187], 'Rare': [31, 465], 'Epic': [33, 238]},
    4: {'Common': [136, 138, 207], 'Rare': [137, 495], 'Epic': [139, 263]},
    5: {'Common': [160, 162, 211], 'Rare': [161, 500], 'Epic': [163, 267]},
    6: {'Common': [8, 10, 183], 'Rare': [9, 460], 'Epic': [11, 234]},
    7: {'Common': [89, 91, 198], 'Rare': [90, 482], 'Epic': [92, 251]},
    8: {'Common': [105, 107, 201], 'Rare': [106, 489], 'Epic': [108, 257]},
    9: {'Common': [60, 62, 193], 'Rare': [61, 474], 'Epic': [63, 244]},
    10: {'Common': [130, 132, 206], 'Rare': [131, 494], 'Epic': [133, 262]},
    11: {'Common': [100, 102, 200], 'Rare': [101, 486], 'Epic': [103, 254]},
    12: {'Common': [50, 52, 191], 'Rare': [51, 472], 'Epic': [53, 242]},
    13: {'Common': [125, 127, 205], 'Rare': [126, 493], 'Epic': [128, 261, 274]},
    14: {'Common': [24, 26, 186], 'Rare': [25, 464], 'Epic': [27, 237]},
    15: {'Common': [120, 122, 204], 'Rare': [121, 492], 'Epic': [123, 260]},
    16: {'Common': [110, 112, 202], 'Rare': [111, 490], 'Epic': [113, 258]},
    17: {'Common': [171, 173, 213], 'Rare': [172, 505], 'Epic': [174, 269, 276]},
    18: {'Common': [55, 57, 192], 'Rare': [56, 473], 'Epic': [58, 243]},
    19: {'Common': [115, 117, 203], 'Rare': [116, 491], 'Epic': [118, 259]},
    20: {'Common': [71, 73, 195], 'Rare': [72, 477], 'Epic': [74, 246]},
    21: {'Common': [77, 79, 196], 'Rare': [78, 479], 'Epic': [80, 249]},
    22: {'Common': [178, 180, 214], 'Rare': [179, 506], 'Epic': [181, 270]},
    23: {'Common': [95, 97, 199], 'Rare': [96, 483], 'Epic': [98, 252]},
    24: {'Common': [141, 143, 208], 'Rare': [142, 496], 'Epic': [144, 264]},
    25: {'Common': [40, 42, 189], 'Rare': [41, 469], 'Epic': [43, 240, 271]},
    26: {'Common': [18, 20, 185], 'Rare': [19, 463], 'Epic': [21, 236]},
    27: {'Common': [1, 3, 182], 'Rare': [2, 458], 'Epic': [4, 233]},
    28: {'Common': [147, 149, 209], 'Rare': [148, 498], 'Epic': [150, 265, 275]},
    29: {'Common': [13, 15, 184], 'Rare': [14, 461], 'Epic': [16, 235]},
    30: {'Common': [66, 68, 194], 'Rare': [67, 476], 'Epic': [69, 245, 273]},
    31: {'Common': [284, 286, 287], 'Rare': [285, 487], 'Epic': [255, 288]},
    32: {'Common': [278, 280, 281], 'Rare': [279, 485], 'Epic': [253, 282]},
    34: {'Common': [84, 86, 197], 'Rare': [85, 481], 'Epic': [87, 250]},
    35: {'Common': [216, 218, 219], 'Rare': [217, 478], 'Epic': [220, 247]},
    36: {'Common': [228, 230, 231], 'Rare': [229, 488], 'Epic': [232, 256, 360]},
    37: {'Common': [165, 167, 212], 'Rare': [166, 501], 'Epic': [168, 268]},
    38: {'Common': [290, 292, 302], 'Rare': [291, 504], 'Epic': [301, 303, 304]},
    39: {'Common': [306, 308, 310], 'Rare': [307, 470], 'Epic': [309, 311]},
    40: {'Common': [321, 323, 325], 'Rare': [322, 459], 'Epic': [324, 326, 327]},
    41: {'Common': [346, 348, 358], 'Rare': [347, 484], 'Epic': [357, 359, 360]},
    42: {'Common': [379, 381, 383], 'Rare': [380, 468], 'Epic': [382, 384, 385]},
    43: {'Common': [370, 372, 374], 'Rare': [371, 475], 'Epic': [373, 375, 376]},
    44: {'Common': [386, 388, 390], 'Rare': [387, 497], 'Epic': [389, 391, 392]},
    45: {'Common': [408, 410, 412], 'Rare': [409, 503], 'Epic': [411, 413, 414]},
    46: {'Common': [416, 418, 420], 'Rare': [417, 462], 'Epic': [419, 421, 422]},
    47: {'Common': [431, 434, 436], 'Rare': [433, 502], 'Epic': [435, 437, 438]},
    48: {'Common': [595, 596, 599], 'Rare': [597, 602], 'Epic': [598, 600, 601]},
    49: {'Common': [440, 441, 444], 'Rare': [442, 467], 'Epic': [443, 445, 446]},
    50: {'Common': [448, 451, 454], 'Rare': [449, 480], 'Epic': [450, 452, 453]},
    51: {'Common': [525, 526, 529], 'Rare': [527, 532], 'Epic': [528, 530, 531]},
    52: {'Common': [553, 555, 557], 'Rare': [554, 560], 'Epic': [556, 558, 559]},
    53: {'Common': [568, 569, 572], 'Rare': [570, 575], 'Epic': [571, 573, 574]},
    54: {'Common': [628, 629, 632], 'Rare': [630, 635], 'Epic': [631, 633, 634]},
    56: {'Common': [659, 660, 663], 'Rare': [661, 666], 'Epic': [662, 664, 665]},
    57: {'Common': [689, 690, 693], 'Rare': [691, 696], 'Epic': [692, 694, 695]},
    58: {'Common': [699, 700, 703], 'Rare': [701, 706], 'Epic': [702, 704, 705]},
    59: {'Common': [739, 740, 743], 'Rare': [741, 746], 'Epic': [742, 744, 745]}
}

class LogicPurchaseOfferCommand(LogicCommand):
    def __init__(self, commandData):
        super().__init__(commandData)

    def encode(self, fields):
        LogicCommand.encode(self, fields)
        self.writeVInt(0)
        self.writeDataReference(0)
        return self.messagePayload

    def decode(self, calling_instance):
        fields = {}
        LogicCommand.decode(calling_instance, fields, False)
        fields["OfferIndex"] = calling_instance.readVInt()
        fields["Brawler"] = calling_instance.readDataReference()
        LogicCommand.parseFields(fields)
        return fields

    def execute(self, calling_instance, fields):
        db_instance = DatabaseHandler()
        player_data = json.loads(db_instance.getPlayerEntry(calling_instance.player.ID)[2])
        ShopData = StaticData.ShopData
        for i in ShopData["Offers"]:
        	if ShopData["Offers"].index(i) == fields["OfferIndex"] and fields["OfferIndex"] != 0:
        		player_data["delivery_items"] = {
                'Boxes': []
                }
        		box = {
                'Type': 0,
                'Items': []
                }
        		if i["Currency"] == 0:
        			player_data["Gems"] -= i["Cost"]
        		elif i["Currency"] == 1:
        			player_data["Coins"] -= i["Cost"]
        		elif i["Currency"] == 3:
        			player_data["StarPoints"] -= i["Cost"]
        		for reward in i["Rewards"]:
        			if reward["ItemType"] == 4:
        				brawlerID = str(Skins.getBrawlerBySkin(self, reward["Extra"]))
        				for i,v in player_data["OwnedBrawlers"].items():
        					if str(i) == brawlerID:
        						v["Skins"].append(reward["Extra"])
        				box['Type'] = 100
        				item = {'Amount': 1, 'DataRef': [29, reward["Extra"]], 'RewardID': 9}
        				box['Items'].append(item)
        				player_data["delivery_items"]['Boxes'].append(box)
        				PinID = Pins.getSkinPin(reward["Extra"])
        				if PinID != None:
        					box = {
        					'Type': 0,
        					'Items': []
        					}
        					player_data["OwnedPins"].append(PinID)
        					box['Type'] = 100
        					item = {'Amount': 1, 'DataRef': [52, PinID], 'RewardID': 11}
        					box['Items'].append(item)
        					player_data["delivery_items"]['Boxes'].append(box)
        				SkinsFromPack = Pins.getSkinsFromPack(Configuration.settings["SkinPack"])
        				PackSkins = False
        				if reward["Extra"] in SkinsFromPack:
        					PackSkins = True
        				if PackSkins == True:
        					ownedSkins = []
        					for brawlerInfo in player_data["OwnedBrawlers"].values():
        					   	try:
        					   		ownedSkins.extend(brawlerInfo["Skins"])
        					   	except KeyError:
        					   		continue
        					SkinsFromSet = True
        					if SkinsFromPack != []:
        						for x in SkinsFromPack:
        							indx = SkinsFromPack.index(x)
        							if SkinsFromPack[indx] not in ownedSkins:
        								SkinsFromSet = False
        					if SkinsFromSet == True:
        						box = {
        						'Type': 0,
        						'Items': []
        						}
        						for x in SkinsFromPack:
        							indx = SkinsFromPack.index(x)
        							pin = Pins.getSkinPinFromPack(SkinsFromPack[indx])
        							player_data["OwnedPins"].append(pin)
        							box['Type'] = 100
        							item = {'Amount': 1, 'DataRef': [52, pin], 'RewardID': 11}
        							box['Items'].append(item)
        						player_data["delivery_items"]['Boxes'].append(box)
        				box = {
        				'Type': 0,
        				'Items': []
        				}
        			if reward["ItemType"] == 3 or reward["ItemType"] == 30:
        				player_data["OwnedBrawlers"][reward["BrawlerID"][1]] = {'CardID': Cards.getBrawlerUnlockID(reward["BrawlerID"][1]), 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': reward["Amount"], 'PowerPoints': 0, 'State': 1}
        				box['Type'] = 100
        				item = {'Amount': reward["Amount"], 'DataRef': [16, reward["BrawlerID"][1]], 'RewardID': 1}
        				box['Items'].append(item)
        				player_data["delivery_items"]['Boxes'].append(box)
        				box = {
        				'Type': 0,
        				'Items': []
        				}
        			if reward["ItemType"] == 19:
        				player_data["OwnedPins"].append(reward["Extra"])
        				box['Type'] = 100
        				item = {'Amount': 1, 'DataRef': [52, reward["Extra"]], 'RewardID': 11}
        				box['Items'].append(item)
        				player_data["delivery_items"]['Boxes'].append(box)
        				box = {
        				'Type': 0,
        				'Items': []
        				}
        			if reward["ItemType"] == 25:
        				player_data["OwnedThumbnails"].append(reward["Extra"])
        				box['Type'] = 100
        				item = {'Amount': 1, 'DataRef': [28, reward["Extra"]], 'RewardID': 11}
        				box['Items'].append(item)
        				player_data["delivery_items"]['Boxes'].append(box)
        				box = {
        				'Type': 0,
        				'Items': []
        				}
        			if reward["ItemType"] == 21:
        				brawlers = list(player_data["OwnedBrawlers"].keys())
        				brawler1 = int(random.choice(brawlers))
        				brawler2 = int(random.choice(brawlers))
        				brawler3 = int(random.choice(brawlers))
        				pin1 = random.choice(BrawlerPins[brawler1]['Common'])
        				pin2 = random.choice(BrawlerPins[brawler2]['Common'])
        				while pin1 == pin2 or pin1 in player_data["OwnedPins"]:
        					pin1 = random.choice(BrawlerPins[brawler1]['Common'])
        				while pin2 == pin1 or pin2 in player_data["OwnedPins"]:
        					pin2 = random.choice(BrawlerPins[brawler2]['Common'])
        				if random.randint(1, 3) == 3:
        					pin3 = random.choice(BrawlerPins[brawler3]['Epic'])
        					while pin3 in player_data["OwnedPins"]:
        						pin3 = random.choice(BrawlerPins[brawler3]['Epic'])
        				else:
        					pin3 = random.choice(BrawlerPins[brawler3]['Rare'])
        					while pin3 in player_data["OwnedPins"]:
        						pin3 = random.choice(BrawlerPins[brawler3]['Rare'])
        				player_data["OwnedPins"].append(pin1)
        				player_data["OwnedPins"].append(pin2)
        				player_data["OwnedPins"].append(pin3)
        				item = {'Amount': 1, 'DataRef': [52, pin1], 'RewardID': 11}
        				box['Type'] = 100
        				box['Items'].append(item)
        				item = {'Amount': 1, 'DataRef': [52, pin2], 'RewardID': 11}
        				box['Items'].append(item)
        				item = {'Amount': 1, 'DataRef': [52, pin3], 'RewardID': 11}
        				box['Items'].append(item)
        				player_data["delivery_items"]['Boxes'].append(box)
        				box = {
        				'Type': 0,
        				'Items': []
        				}
        			if reward["ItemType"] == 23:
        				brawlers = list(player_data["OwnedBrawlers"].keys())
        				brawler = int(random.choice(brawlers))
        				if reward["Extra"] == 0:
        					pin = random.choice(BrawlerPins[brawler]['Common'])
        					while pin in player_data["OwnedPins"]:
        						pin = random.choice(BrawlerPins[brawler]['Common'])
        					#player_data["Gems"] -= 9
        				if reward["Extra"] == 1:
        					pin = random.choice(BrawlerPins[brawler]['Rare'])
        					while pin in player_data["OwnedPins"]:
        						pin = random.choice(BrawlerPins[brawler]['Rare'])
        					#player_data["Gems"] -= 29
        				if reward["Extra"] == 2:
        					pin = random.choice(BrawlerPins[brawler]['Epic'])
        					while pin in player_data["OwnedPins"]:
        						pin = random.choice(BrawlerPins[brawler]['Epic'])
        					#player_data["Gems"] -= 39
        				player_data["OwnedPins"].append(pin)
        				item = {'Amount': 1, 'DataRef': [52, pin], 'RewardID': 11}
        				box['Items'].append(item)
        				box['Type'] = 100
        				player_data["delivery_items"]['Boxes'].append(box)
        				box = {
        				'Type': 0,
        				'Items': []
        				}
        			if reward["ItemType"] == 27:
        				brawlers = list(player_data["OwnedBrawlers"].keys())
        				brawler1 = int(random.choice(brawlers))
        				brawler2 = int(random.choice(brawlers))
        				brawler3 = int(random.choice(brawlers))
        				if reward["Extra"] == 0:
        					pin1 = random.choice(BrawlerPins[brawler1]['Common'])
        					pin2 = random.choice(BrawlerPins[brawler2]['Common'])
        					pin3 = random.choice(BrawlerPins[brawler3]['Common'])
        					while pin1 == pin2 or pin1 in player_data["OwnedPins"]:
        						pin1 = random.choice(BrawlerPins[brawler1]['Common'])
        					while pin2 == pin1 or pin2 in player_data["OwnedPins"]:
        						pin2 = random.choice(BrawlerPins[brawler2]['Common'])
        					while pin3 == pin2 or pin3 == pin1 or pin3 in player_data["OwnedPins"]:
        						pin3 = random.choice(BrawlerPins[brawler3]['Common'])
        				if reward["Extra"] == 1:
        					pin1 = random.choice(BrawlerPins[brawler1]['Rare'])
        					pin2 = random.choice(BrawlerPins[brawler2]['Rare'])
        					pin3 = random.choice(BrawlerPins[brawler3]['Rare'])
        					while pin1 == pin2 or pin1 in player_data["OwnedPins"]:
        						pin1 = random.choice(BrawlerPins[brawler1]['Rare'])
        					while pin2 == pin1 or pin2 in player_data["OwnedPins"]:
        						pin2 = random.choice(BrawlerPins[brawler2]['Rare'])
        					while pin3 == pin2 or pin3 == pin1 or pin3 in player_data["OwnedPins"]:
        						pin3 = random.choice(BrawlerPins[brawler3]['Rare'])
        				if reward["Extra"] == 2:
        					pin1 = random.choice(BrawlerPins[brawler1]['Epic'])
        					pin2 = random.choice(BrawlerPins[brawler2]['Epic'])
        					pin3 = random.choice(BrawlerPins[brawler3]['Epic'])
        					while pin1 == pin2 or pin1 in player_data["OwnedPins"]:
        						pin1 = random.choice(BrawlerPins[brawler1]['Epic'])
        					while pin2 == pin1 or pin2 in player_data["OwnedPins"]:
        						pin2 = random.choice(BrawlerPins[brawler2]['Epic'])
        					while pin3 == pin2 or pin3 == pin1 or pin3 in player_data["OwnedPins"]:
        						pin3 = random.choice(BrawlerPins[brawler3]['Epic'])
        				player_data["OwnedPins"].append(pin1)
        				player_data["OwnedPins"].append(pin2)
        				player_data["OwnedPins"].append(pin3)
        				box = {'Type': 0, 'Items': []}
        				item = {'Amount': 1, 'DataRef': [52, pin1], 'RewardID': 11}
        				box['Type'] = 100
        				box['Items'].append(item)
        				item = {'Amount': 1, 'DataRef': [52, pin2], 'RewardID': 11}
        				box['Items'].append(item)
        				item = {'Amount': 1, 'DataRef': [52, pin3], 'RewardID': 11}
        				box['Items'].append(item)
        				player_data["delivery_items"]['Boxes'].append(box)
        				box = {
        				'Type': 0,
        				'Items': []
        				}
        			if reward["ItemType"] == 12:
        				brawler = fields["Brawler"][1]
        				for i,v in player_data["OwnedBrawlers"].items():
        					if i == str(brawler):
        						v["PowerPoints"] += reward["Amount"]
        				box['Type'] = 100
        				item = {'Amount': reward["Amount"], 'DataRef': [16, brawler], 'RewardID': 6}
        				box['Items'].append(item)
        				player_data["delivery_items"]['Boxes'].append(box)
        				box = {
        				'Type': 0,
        				'Items': []
        				}
        			if reward["ItemType"] == 1:
        				player_data["Coins"] += reward["Amount"]
        				box['Type'] = 100
        				item = {'Amount': reward["Amount"], 'DataRef': [0, 0], 'RewardID': 7}
        				box['Items'].append(item)
        				player_data["delivery_items"]['Boxes'].append(box)
        				box = {
        				'Type': 0,
        				'Items': []
        				}
        			if reward["ItemType"] == 16:
        				player_data["Gems"] += reward["Amount"]
        				box['Type'] = 100
        				item = {'Amount': reward["Amount"], 'DataRef': [0, 0], 'RewardID': 8}
        				box['Items'].append(item)
        				player_data["delivery_items"]['Boxes'].append(box)
        				box = {
        				'Type': 0,
        				'Items': []
        				}
        			if reward["ItemType"] == 6 or reward["ItemType"] == 0:
        				for x in range(reward["Amount"]):
        					box = {
        					'Type': 0,
        					'Items': []
        					}
        					box['Type'] = 10
        					brawlers= list(player_data["OwnedBrawlers"].keys())
        					pp1= random.randint(9,69)
        					pp2 = random.randint(9,69)
        					pp3 = random.randint(9,69)
        					ppbr = random.randint(20, 54)
        					brawlerID1= random.choice(brawlers)
        					brawlerID2 = random.choice(brawlers)
        					brawlerID3 = random.choice(brawlers)
        					while brawlerID2 == brawlerID1 or brawlerID2 == brawlerID3:
        						brawlerID2 = random.choice(brawlers)
        					while brawlerID3 == brawlerID1 or brawlerID3 == brawlerID2:
        						brawlerID3 = random.choice(brawlers)
        					if len(brawlers) != len(Characters.getBrawlersID()):
        						brawlerID6 = random.randint(0, 59)
        						while brawlerID6 == 33 or brawlerID6 == 55 or str(brawlerID6) in brawlers:
        							brawlerID6 = random.randint(0, 59)
        					if random.randint(0, 15) == 3 and len(brawlers) != len(Characters.getBrawlersID()):
        						item = {'Amount': 1, 'DataRef': [16, brawlerID6], 'RewardID': 1}
        						box['Items'].append(item)
        						player_data["OwnedBrawlers"][brawlerID6] = {'CardID': Cards.getBrawlerUnlockID(brawlerID6), 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 1}
        					elif random.randint(0, 9) == 2:
        					   item = {'Amount': ppbr, 'DataRef': [0, 0], 'RewardID': 19}
        					   box['Items'].append(item)
        					else:
        					   gold = random.randint(7, 59)
        					   if random.randint(0, 10) == 7:
        					   	gems = random.randint(15, 30)
        					   elif random.randint(0, 5) == 2:
        					   	gems = random.randint(7, 19)
        					   else:
        					   	gems = random.randint(3, 11)
        					   item = {'Amount': gold, 'DataRef': [0, 0], 'RewardID': 7}
        					   box['Items'].append(item)
        					   item = {'Amount': pp1, 'DataRef': [16, brawlerID1], 'RewardID': 6}
        					   box['Items'].append(item)
        					   item = {'Amount': pp2, 'DataRef': [16, brawlerID2], 'RewardID': 6}
        					   box['Items'].append(item)
        					   item = {'Amount': pp3, 'DataRef': [16, brawlerID3], 'RewardID': 6}
        					   box['Items'].append(item)
        					   for i,v in player_data["OwnedBrawlers"].items():
        					   	if i == str(brawlerID1):
        					   		v["PowerPoints"] += pp1
        					   for i,v in player_data["OwnedBrawlers"].items():
        					   	if i == str(brawlerID2):
        					   		v["PowerPoints"] += pp2
        					   for i,v in player_data["OwnedBrawlers"].items():
        					   	if i == str(brawlerID3):
        					   		v["PowerPoints"] += pp3
        					   if random.randint(0, 3) == 2:
        					   	 item = {'Amount': gems, 'DataRef': [0, 0], 'RewardID': 8}
        					   	 box['Items'].append(item)
        					   	 player_data["Gems"] += gems
        					   player_data["Coins"] += gold
        					   player_data["delivery_items"]['Boxes'].append(box)
        			if reward["ItemType"] == 10:
        				for x in range(reward["Amount"]):
        					box = {
        					'Type': 0,
        					'Items': []
        					}
        					brawlers= list(player_data["OwnedBrawlers"].keys())
        					pp1= random.randint(9,127)
        					pp2 = random.randint(9,127)
        					pp3 = random.randint(9,127)
        					pp4 = random.randint(9,127)
        					pp5 = random.randint(9,127)
        					ppbr = random.randint(75, 120)
        					brawlerID1= random.choice(brawlers)
        					brawlerID2 = random.choice(brawlers)
        					brawlerID3 = random.choice(brawlers)
        					brawlerID4 = random.choice(brawlers)
        					brawlerID5 = random.choice(brawlers)
        					while brawlerID2 == brawlerID1 or brawlerID2 == brawlerID3:
        						brawlerID2 = random.choice(brawlers)
        					while brawlerID3 == brawlerID1 or brawlerID3 == brawlerID2:
        						brawlerID3 = random.choice(brawlers)
        					if len(brawlers) >= 4:
        						while brawlerID4 == brawlerID1 or brawlerID4 == brawlerID2 or brawlerID4 == brawlerID3 or brawlerID4 == brawlerID5:
        								brawlerID4 = random.choice(brawlers)
        					if len(brawlers) >= 5:
        						 while brawlerID5 == brawlerID1 or brawlerID5 == brawlerID2 or brawlerID5 == brawlerID3 or brawlerID5 == brawlerID4:
        						 	 brawlerID5 = random.choice(brawlers)
        					if len(brawlers) != len(Characters.getBrawlersID()):
        						 brawlerID6 = random.randint(0, 59)
        						 while brawlerID6 == 33 or brawlerID6 == 55 or str(brawlerID6) in brawlers:
        						 	brawlerID6 = random.randint(0, 59)
        					gold = random.randint(53, 271)
        					if random.randint(0, 10) == 7:
        						gems = random.randint(30, 90)
        					elif random.randint(0, 5) == 2:
        						gems = random.randint(20, 50)
        					else:
        						gems = random.randint(5, 30)
        					box['Type'] = 11
        					item = {'Amount': gold, 'DataRef': [0, 0], 'RewardID': 7}
        					box['Items'].append(item)
        					item = {'Amount': pp1, 'DataRef': [16, brawlerID1], 'RewardID': 6}
        					box['Items'].append(item)
        					item = {'Amount': pp2, 'DataRef': [16, brawlerID2], 'RewardID': 6}
        					box['Items'].append(item)
        					item = {'Amount': pp3, 'DataRef': [16, brawlerID3], 'RewardID': 6}
        					box['Items'].append(item)
        					for i,v in player_data["OwnedBrawlers"].items():
        						 if i == str(brawlerID1):
        						 	v["PowerPoints"] += pp1
        					for i,v in player_data["OwnedBrawlers"].items():
        						 if i == str(brawlerID2):
        						 	v["PowerPoints"] += pp2
        					for i,v in player_data["OwnedBrawlers"].items():
        						 if i == str(brawlerID3):
        						 	v["PowerPoints"] += pp3
        					if len(brawlers) >= 4:
        						 item = {'Amount': pp4, 'DataRef': [16, brawlerID4], 'RewardID': 6}
        						 box['Items'].append(item)
        						 for i,v in player_data["OwnedBrawlers"].items():
        						 	if i == str(brawlerID4):
        						 		v["PowerPoints"] += pp4
        					if len(brawlers) >= 5:
        						 item = {'Amount': pp5, 'DataRef': [16, brawlerID5], 'RewardID': 6}
        						 box['Items'].append(item)
        						 for i,v in player_data["OwnedBrawlers"].items():
        						 	if i == str(brawlerID5):
        						 		v["PowerPoints"] += pp5
        					if random.randint(0, 5) == 3:
        						 if len(brawlers) != len(Characters.getBrawlersID()):
        						 	item = {'Amount': 1, 'DataRef': [16, brawlerID6], 'RewardID': 1}
        						 	box['Items'].append(item)
        						 	player_data["OwnedBrawlers"][brawlerID6] = {'CardID': Cards.getBrawlerUnlockID(brawlerID6), 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 1}
        					else:
        						 if random.randint(0, 3) == 2:
        						 	item = {'Amount': ppbr, 'DataRef': [0, 0], 'RewardID': 19}
        						 	box['Items'].append(item)
        					if random.randint(0, 3) == 2:
        						 item = {'Amount': gems, 'DataRef': [0, 0], 'RewardID': 8}
        						 box['Items'].append(item)
        						 player_data["Gems"] += gems
        					player_data["Coins"] += gold
        					player_data["delivery_items"]['Boxes'].append(box)
        		
        		box = {
        		'Type': 0,
        		'Items': []
        		}
        if fields["OfferIndex"] == 0:
            player_data["PushasedOffers"].append(-3)
            player_data["delivery_items"] = {
                'Boxes': []
            }
            box = {
        	'Type': 0,
        	'Items': []
        	}
            box['Type'] = 100
            brawlers = Characters.getBrawlersID()
            for x in brawlers:
            	if x not in player_data["OwnedBrawlers"]:
            		player_data["OwnedBrawlers"][x] = {'CardID': Cards.getBrawlerUnlockID(x), 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 1}
            		item = {'Amount': 1, 'DataRef': [16, x], 'RewardID': 1}
            		box['Items'].append(item)
            player_data["delivery_items"]['Boxes'].append(box)

        for i in ShopData["Offers"]:
        	if ShopData["Offers"].index(i) == fields["OfferIndex"] and i["Claim"] != True:
        		if i["OfferID"] not in player_data["PushasedOffers"]:
        				player_data["PushasedOffers"].append(i["OfferID"])
        				db_instance.updatePlayerData(player_data, calling_instance)
        				fields["Socket"] = calling_instance.client
        				fields["Command"] = {"ID": 203}
        				fields["PlayerID"] = calling_instance.player.ID
        				Messaging.sendMessage(24111, fields)
        
        
        for reward in player_data["DailyOffers"]:
        	if player_data["DailyOffers"].index(reward) == fields["OfferIndex"] - len(ShopData["Offers"]):
        		player_data["delivery_items"] = {
                'Boxes': []
                }
        		box = {
                'Type': 0,
                'Items': []
                }
        		if reward["Currency"] == 0:
        			player_data["Gems"] -= reward["Cost"]
        		elif reward["Currency"] == 1:
        			player_data["Coins"] -= reward["Cost"]
        		elif reward["Currency"] == 3:
        			player_data["StarPoints"] -= reward["Cost"]
        		if reward["ItemType"] == 4:
        				brawlerID = str(Skins.getBrawlerBySkin(self, reward["Extra"]))
        				for i,v in player_data["OwnedBrawlers"].items():
        					if str(i) == brawlerID:
        						v["Skins"].append(reward["Extra"])
        				box['Type'] = 100
        				item = {'Amount': 1, 'DataRef': [29, reward["Extra"]], 'RewardID': 9}
        				box['Items'].append(item)
        				player_data["delivery_items"]['Boxes'].append(box)
        				PinID = Pins.getSkinPin(reward["Extra"])
        				if PinID != None:
        					box = {
        					'Type': 0,
        					'Items': []
        					}
        					player_data["OwnedPins"].append(PinID)
        					box['Type'] = 100
        					item = {'Amount': 1, 'DataRef': [52, PinID], 'RewardID': 11}
        					box['Items'].append(item)
        					player_data["delivery_items"]['Boxes'].append(box)
        				box = {
        				'Type': 0,
        				'Items': []
        				}
        		if reward["ItemType"] == 3 or reward["ItemType"] == 30:
        				player_data["OwnedBrawlers"][reward["BrawlerID"][1]] = {'CardID': Cards.getBrawlerUnlockID(reward["BrawlerID"][1]), 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': reward["Amount"], 'PowerPoints': 0, 'State': 1}
        				box['Type'] = 100
        				item = {'Amount': reward["Amount"], 'DataRef': [16, reward["BrawlerID"][1]], 'RewardID': 1}
        				box['Items'].append(item)
        				player_data["delivery_items"]['Boxes'].append(box)
        				box = {
        				'Type': 0,
        				'Items': []
        				}
        		if reward["ItemType"] == 19:
        				player_data["OwnedPins"].append(reward["Extra"])
        				box['Type'] = 100
        				item = {'Amount': 1, 'DataRef': [52, reward["Extra"]], 'RewardID': 11}
        				box['Items'].append(item)
        				player_data["delivery_items"]['Boxes'].append(box)
        				box = {
        				'Type': 0,
        				'Items': []
        				}
        		if reward["ItemType"] == 25:
        				player_data["OwnedThumbnails"].append(reward["Extra"])
        				box['Type'] = 100
        				item = {'Amount': 1, 'DataRef': [28, reward["Extra"]], 'RewardID': 11}
        				box['Items'].append(item)
        				player_data["delivery_items"]['Boxes'].append(box)
        				box = {
        				'Type': 0,
        				'Items': []
        				}
        		if reward["ItemType"] == 21:
        				brawlers = list(player_data["OwnedBrawlers"].keys())
        				brawler1 = int(random.choice(brawlers))
        				brawler2 = int(random.choice(brawlers))
        				brawler3 = int(random.choice(brawlers))
        				pin1 = random.choice(BrawlerPins[brawler1]['Common'])
        				pin2 = random.choice(BrawlerPins[brawler2]['Common'])
        				while pin1 == pin2 or pin1 in player_data["OwnedPins"]:
        					pin1 = random.choice(BrawlerPins[brawler1]['Common'])
        				while pin2 == pin1 or pin2 in player_data["OwnedPins"]:
        					pin2 = random.choice(BrawlerPins[brawler2]['Common'])
        				if random.randint(1, 3) == 3:
        					pin3 = random.choice(BrawlerPins[brawler3]['Epic'])
        					while pin3 in player_data["OwnedPins"]:
        						pin3 = random.choice(BrawlerPins[brawler3]['Epic'])
        				else:
        					pin3 = random.choice(BrawlerPins[brawler3]['Rare'])
        					while pin3 in player_data["OwnedPins"]:
        						pin3 = random.choice(BrawlerPins[brawler3]['Rare'])
        				player_data["OwnedPins"].append(pin1)
        				player_data["OwnedPins"].append(pin2)
        				player_data["OwnedPins"].append(pin3)
        				item = {'Amount': 1, 'DataRef': [52, pin1], 'RewardID': 11}
        				box['Type'] = 100
        				box['Items'].append(item)
        				item = {'Amount': 1, 'DataRef': [52, pin2], 'RewardID': 11}
        				box['Items'].append(item)
        				item = {'Amount': 1, 'DataRef': [52, pin3], 'RewardID': 11}
        				box['Items'].append(item)
        				player_data["delivery_items"]['Boxes'].append(box)
        				box = {
        				'Type': 0,
        				'Items': []
        				}
        		if reward["ItemType"] == 23:
        				brawlers = list(player_data["OwnedBrawlers"].keys())
        				brawler = int(random.choice(brawlers))
        				if reward["Extra"] == 0:
        					pin = random.choice(BrawlerPins[brawler]['Common'])
        					while pin in player_data["OwnedPins"]:
        						pin = random.choice(BrawlerPins[brawler]['Common'])
        					#player_data["Gems"] -= 9
        				if reward["Extra"] == 1:
        					pin = random.choice(BrawlerPins[brawler]['Rare'])
        					while pin in player_data["OwnedPins"]:
        						pin = random.choice(BrawlerPins[brawler]['Rare'])
        					#player_data["Gems"] -= 29
        				if reward["Extra"] == 2:
        					pin = random.choice(BrawlerPins[brawler]['Epic'])
        					while pin in player_data["OwnedPins"]:
        						pin = random.choice(BrawlerPins[brawler]['Epic'])
        					#player_data["Gems"] -= 39
        				player_data["OwnedPins"].append(pin)
        				item = {'Amount': 1, 'DataRef': [52, pin], 'RewardID': 11}
        				box['Items'].append(item)
        				box['Type'] = 100
        				player_data["delivery_items"]['Boxes'].append(box)
        				box = {
        				'Type': 0,
        				'Items': []
        				}
        		if reward["ItemType"] == 27:
        				brawlers = list(player_data["OwnedBrawlers"].keys())
        				brawler1 = int(random.choice(brawlers))
        				brawler2 = int(random.choice(brawlers))
        				brawler3 = int(random.choice(brawlers))
        				if reward["Extra"] == 0:
        					pin1 = random.choice(BrawlerPins[brawler1]['Common'])
        					pin2 = random.choice(BrawlerPins[brawler2]['Common'])
        					pin3 = random.choice(BrawlerPins[brawler3]['Common'])
        					while pin1 == pin2 or pin1 in player_data["OwnedPins"]:
        						pin1 = random.choice(BrawlerPins[brawler1]['Common'])
        					while pin2 == pin1 or pin2 in player_data["OwnedPins"]:
        						pin2 = random.choice(BrawlerPins[brawler2]['Common'])
        					while pin3 == pin2 or pin3 == pin1 or pin3 in player_data["OwnedPins"]:
        						pin3 = random.choice(BrawlerPins[brawler3]['Common'])
        				if reward["Extra"] == 1:
        					pin1 = random.choice(BrawlerPins[brawler1]['Rare'])
        					pin2 = random.choice(BrawlerPins[brawler2]['Rare'])
        					pin3 = random.choice(BrawlerPins[brawler3]['Rare'])
        					while pin1 == pin2 or pin1 in player_data["OwnedPins"]:
        						pin1 = random.choice(BrawlerPins[brawler1]['Rare'])
        					while pin2 == pin1 or pin2 in player_data["OwnedPins"]:
        						pin2 = random.choice(BrawlerPins[brawler2]['Rare'])
        					while pin3 == pin2 or pin3 == pin1 or pin3 in player_data["OwnedPins"]:
        						pin3 = random.choice(BrawlerPins[brawler3]['Rare'])
        				if reward["Extra"] == 2:
        					pin1 = random.choice(BrawlerPins[brawler1]['Epic'])
        					pin2 = random.choice(BrawlerPins[brawler2]['Epic'])
        					pin3 = random.choice(BrawlerPins[brawler3]['Epic'])
        					while pin1 == pin2 or pin1 in player_data["OwnedPins"]:
        						pin1 = random.choice(BrawlerPins[brawler1]['Epic'])
        					while pin2 == pin1 or pin2 in player_data["OwnedPins"]:
        						pin2 = random.choice(BrawlerPins[brawler2]['Epic'])
        					while pin3 == pin2 or pin3 == pin1 or pin3 in player_data["OwnedPins"]:
        						pin3 = random.choice(BrawlerPins[brawler3]['Epic'])
        				player_data["OwnedPins"].append(pin1)
        				player_data["OwnedPins"].append(pin2)
        				player_data["OwnedPins"].append(pin3)
        				box = {'Type': 0, 'Items': []}
        				item = {'Amount': 1, 'DataRef': [52, pin1], 'RewardID': 11}
        				box['Type'] = 100
        				box['Items'].append(item)
        				item = {'Amount': 1, 'DataRef': [52, pin2], 'RewardID': 11}
        				box['Items'].append(item)
        				item = {'Amount': 1, 'DataRef': [52, pin3], 'RewardID': 11}
        				box['Items'].append(item)
        				player_data["delivery_items"]['Boxes'].append(box)
        				box = {
        				'Type': 0,
        				'Items': []
        				}
        		if reward["ItemType"] == 12:
        				brawler = fields["Brawler"][1]
        				for i,v in player_data["OwnedBrawlers"].items():
        					if i == str(brawler):
        						v["PowerPoints"] += reward["Amount"]
        				box['Type'] = 100
        				item = {'Amount': reward["Amount"], 'DataRef': [16, brawler], 'RewardID': 6}
        				box['Items'].append(item)
        				player_data["delivery_items"]['Boxes'].append(box)
        				box = {
        				'Type': 0,
        				'Items': []
        				}
        		if reward["ItemType"] == 1:
        				player_data["Coins"] += reward["Amount"]
        				box['Type'] = 100
        				item = {'Amount': reward["Amount"], 'DataRef': [0, 0], 'RewardID': 7}
        				box['Items'].append(item)
        				player_data["delivery_items"]['Boxes'].append(box)
        				box = {
        				'Type': 0,
        				'Items': []
        				}
        		if reward["ItemType"] == 16:
        				player_data["Gems"] += reward["Amount"]
        				box['Type'] = 100
        				item = {'Amount': reward["Amount"], 'DataRef': [0, 0], 'RewardID': 8}
        				box['Items'].append(item)
        				player_data["delivery_items"]['Boxes'].append(box)
        				box = {
        				'Type': 0,
        				'Items': []
        				}
        		if reward["ItemType"] == 6 or reward["ItemType"] == 0:
        				for x in range(reward["Amount"]):
        					box = {
        					'Type': 0,
        					'Items': []
        					}
        					box['Type'] = 10
        					brawlers= list(player_data["OwnedBrawlers"].keys())
        					pp1= random.randint(9,69)
        					pp2 = random.randint(9,69)
        					pp3 = random.randint(9,69)
        					ppbr = random.randint(20, 54)
        					brawlerID1= random.choice(brawlers)
        					brawlerID2 = random.choice(brawlers)
        					brawlerID3 = random.choice(brawlers)
        					while brawlerID2 == brawlerID1 or brawlerID2 == brawlerID3:
        						brawlerID2 = random.choice(brawlers)
        					while brawlerID3 == brawlerID1 or brawlerID3 == brawlerID2:
        						brawlerID3 = random.choice(brawlers)
        					if len(brawlers) != len(Characters.getBrawlersID()):
        						brawlerID6 = random.randint(0, 59)
        						while brawlerID6 == 33 or brawlerID6 == 55 or str(brawlerID6) in brawlers:
        							brawlerID6 = random.randint(0, 59)
        					if random.randint(0, 15) == 3 and len(brawlers) != len(Characters.getBrawlersID()):
        						item = {'Amount': 1, 'DataRef': [16, brawlerID6], 'RewardID': 1}
        						box['Items'].append(item)
        						player_data["OwnedBrawlers"][brawlerID6] = {'CardID': Cards.getBrawlerUnlockID(brawlerID6), 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 1}
        					elif random.randint(0, 9) == 2:
        					   item = {'Amount': ppbr, 'DataRef': [0, 0], 'RewardID': 19}
        					   box['Items'].append(item)
        					else:
        					   gold = random.randint(7, 59)
        					   if random.randint(0, 10) == 7:
        					   	gems = random.randint(15, 30)
        					   elif random.randint(0, 5) == 2:
        					   	gems = random.randint(7, 19)
        					   else:
        					   	gems = random.randint(3, 11)
        					   item = {'Amount': gold, 'DataRef': [0, 0], 'RewardID': 7}
        					   box['Items'].append(item)
        					   item = {'Amount': pp1, 'DataRef': [16, brawlerID1], 'RewardID': 6}
        					   box['Items'].append(item)
        					   item = {'Amount': pp2, 'DataRef': [16, brawlerID2], 'RewardID': 6}
        					   box['Items'].append(item)
        					   item = {'Amount': pp3, 'DataRef': [16, brawlerID3], 'RewardID': 6}
        					   box['Items'].append(item)
        					   for i,v in player_data["OwnedBrawlers"].items():
        					   	if i == str(brawlerID1):
        					   		v["PowerPoints"] += pp1
        					   for i,v in player_data["OwnedBrawlers"].items():
        					   	if i == str(brawlerID2):
        					   		v["PowerPoints"] += pp2
        					   for i,v in player_data["OwnedBrawlers"].items():
        					   	if i == str(brawlerID3):
        					   		v["PowerPoints"] += pp3
        					   if random.randint(0, 3) == 2:
        					   	 item = {'Amount': gems, 'DataRef': [0, 0], 'RewardID': 8}
        					   	 box['Items'].append(item)
        					   	 player_data["Gems"] += gems
        					   player_data["Coins"] += gold
        					   player_data["delivery_items"]['Boxes'].append(box)
        		if reward["ItemType"] == 10:
        				for x in range(reward["Amount"]):
        					box = {
        					'Type': 0,
        					'Items': []
        					}
        					brawlers= list(player_data["OwnedBrawlers"].keys())
        					pp1= random.randint(9,127)
        					pp2 = random.randint(9,127)
        					pp3 = random.randint(9,127)
        					pp4 = random.randint(9,127)
        					pp5 = random.randint(9,127)
        					ppbr = random.randint(75, 120)
        					brawlerID1= random.choice(brawlers)
        					brawlerID2 = random.choice(brawlers)
        					brawlerID3 = random.choice(brawlers)
        					brawlerID4 = random.choice(brawlers)
        					brawlerID5 = random.choice(brawlers)
        					while brawlerID2 == brawlerID1 or brawlerID2 == brawlerID3:
        						brawlerID2 = random.choice(brawlers)
        					while brawlerID3 == brawlerID1 or brawlerID3 == brawlerID2:
        						brawlerID3 = random.choice(brawlers)
        					if len(brawlers) >= 4:
        						while brawlerID4 == brawlerID1 or brawlerID4 == brawlerID2 or brawlerID4 == brawlerID3 or brawlerID4 == brawlerID5:
        								brawlerID4 = random.choice(brawlers)
        					if len(brawlers) >= 5:
        						 while brawlerID5 == brawlerID1 or brawlerID5 == brawlerID2 or brawlerID5 == brawlerID3 or brawlerID5 == brawlerID4:
        						 	 brawlerID5 = random.choice(brawlers)
        					if len(brawlers) != len(Characters.getBrawlersID()):
        						 brawlerID6 = random.randint(0, 59)
        						 while brawlerID6 == 33 or brawlerID6 == 55 or str(brawlerID6) in brawlers:
        						 	brawlerID6 = random.randint(0, 59)
        					gold = random.randint(53, 271)
        					if random.randint(0, 10) == 7:
        						gems = random.randint(30, 90)
        					elif random.randint(0, 5) == 2:
        						gems = random.randint(20, 50)
        					else:
        						gems = random.randint(5, 30)
        					box['Type'] = 11
        					item = {'Amount': gold, 'DataRef': [0, 0], 'RewardID': 7}
        					box['Items'].append(item)
        					item = {'Amount': pp1, 'DataRef': [16, brawlerID1], 'RewardID': 6}
        					box['Items'].append(item)
        					item = {'Amount': pp2, 'DataRef': [16, brawlerID2], 'RewardID': 6}
        					box['Items'].append(item)
        					item = {'Amount': pp3, 'DataRef': [16, brawlerID3], 'RewardID': 6}
        					box['Items'].append(item)
        					for i,v in player_data["OwnedBrawlers"].items():
        						 if i == str(brawlerID1):
        						 	v["PowerPoints"] += pp1
        					for i,v in player_data["OwnedBrawlers"].items():
        						 if i == str(brawlerID2):
        						 	v["PowerPoints"] += pp2
        					for i,v in player_data["OwnedBrawlers"].items():
        						 if i == str(brawlerID3):
        						 	v["PowerPoints"] += pp3
        					if len(brawlers) >= 4:
        						 item = {'Amount': pp4, 'DataRef': [16, brawlerID4], 'RewardID': 6}
        						 box['Items'].append(item)
        						 for i,v in player_data["OwnedBrawlers"].items():
        						 	if i == str(brawlerID4):
        						 		v["PowerPoints"] += pp4
        					if len(brawlers) >= 5:
        						 item = {'Amount': pp5, 'DataRef': [16, brawlerID5], 'RewardID': 6}
        						 box['Items'].append(item)
        						 for i,v in player_data["OwnedBrawlers"].items():
        						 	if i == str(brawlerID5):
        						 		v["PowerPoints"] += pp5
        					if random.randint(0, 5) == 3:
        						 if len(brawlers) != len(Characters.getBrawlersID()):
        						 	item = {'Amount': 1, 'DataRef': [16, brawlerID6], 'RewardID': 1}
        						 	box['Items'].append(item)
        						 	player_data["OwnedBrawlers"][brawlerID6] = {'CardID': Cards.getBrawlerUnlockID(brawlerID6), 'Skins': [], 'Trophies': 0, 'HighestTrophies': 0, 'PowerLevel': 1, 'PowerPoints': 0, 'State': 1}
        					else:
        						 if random.randint(0, 3) == 2:
        						 	item = {'Amount': ppbr, 'DataRef': [0, 0], 'RewardID': 19}
        						 	box['Items'].append(item)
        					if random.randint(0, 3) == 2:
        						 item = {'Amount': gems, 'DataRef': [0, 0], 'RewardID': 8}
        						 box['Items'].append(item)
        						 player_data["Gems"] += gems
        					player_data["Coins"] += gold
        					player_data["delivery_items"]['Boxes'].append(box)
        		
        		box = {
        		'Type': 0,
        		'Items': []
        		}
        for reward in player_data["DailyOffers"]:
        	if player_data["DailyOffers"].index(reward) == fields["OfferIndex"] - len(ShopData["Offers"]) and reward["Claim"] != True:
        		reward["Claim"] = True
        		db_instance.updatePlayerData(player_data, calling_instance)
        		fields["Socket"] = calling_instance.client
        		fields["Command"] = {"ID": 203}
        		fields["PlayerID"] = calling_instance.player.ID
        		Messaging.sendMessage(24111, fields)


    def getCommandType(self):
        return 519