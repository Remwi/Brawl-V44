import json

from Classes.Commands.LogicCommand import LogicCommand
from Classes.Messaging import Messaging
from Database.DatabaseHandler import DatabaseHandler
import Configuration


class LogicClaimDailyRewardCommand(LogicCommand):
    def __init__(self, commandData):
        super().__init__(commandData)

    def encode(self, fields):
        pass

    def decode(self, calling_instance):
        fields = {}
        LogicCommand.decode(calling_instance, fields, False)
        fields["EventSlot"] = calling_instance.readVInt()
        fields["State"] = calling_instance.readVInt()
        LogicCommand.parseFields(fields)
        return fields

    def execute(self, calling_instance, fields):
        db_instance = DatabaseHandler()
        player_data = json.loads(db_instance.getPlayerEntry(calling_instance.player.ID)[2])
        if fields["EventSlot"] >= 20:
        	try:
        		player_data["Challenges"]
        	except KeyError:
        		player_data["Challenges"] = {}
        	try:
        	    challenge = Configuration.settings["ChallengeLogicName"]
        	    player_data["Challenges"][challenge]
        	except KeyError:
        		player_data["Challenges"][challenge] = {'Seen': True, 'Defeates': 0, 'Wins': 0}
        	challenge = Configuration.settings["ChallengeLogicName"]
        	if player_data["Challenges"][challenge]['Seen'] == False:
        		player_data["Challenges"][challenge]['Seen'] = True
        	db_instance.updatePlayerData(player_data, calling_instance)
        	pass
        player_data["BPTokens"] += 5
        db_instance.updatePlayerData(player_data, calling_instance)

    def getCommandType(self):
        return 503