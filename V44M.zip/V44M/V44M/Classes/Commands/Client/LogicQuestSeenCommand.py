import json

from Classes.Commands.LogicCommand import LogicCommand
from Classes.Messaging import Messaging
from Database.DatabaseHandler import DatabaseHandler


class LogicQuestSeenCommand(LogicCommand):
    def __init__(self, commandData):
        super().__init__(commandData)

    def encode(self, fields):
        pass

    def decode(self, calling_instance):
        fields = {}
        LogicCommand.decode(calling_instance, fields, False)
        LogicCommand.parseFields(fields)
        return fields

    def execute(self, calling_instance, fields):
        pass
        #fields["Socket"] = calling_instance.client
#        fields["Command"] = {"ID": 211}
#        fields["PlayerID"] = calling_instance.player.ID
#        Messaging.sendMessage(24111, fields)

    def getCommandType(self):
        return 533